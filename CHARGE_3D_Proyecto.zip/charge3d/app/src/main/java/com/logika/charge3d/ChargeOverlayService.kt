package com.logika.charge3d

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat

class ChargeOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: ChargeSceneView? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val channelId = "charge3d_running"

    override fun onBind(intent: Intent?) = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopOverlay(); stopSelf(); return START_NOT_STICKY }
        createChannel()
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("CHARGE 3D activo")
            .setContentText("Animación de carga en pantalla. Tocá dos veces para cerrar.")
            .setOngoing(true).build()
        startForeground(31, notification)
        if (overlay == null && android.provider.Settings.canDrawOverlays(this)) showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP, "CHARGE3D:Screen")
        try { wakeLock?.acquire(10 * 60 * 60 * 1000L) } catch (_: Exception) {}
        val view = ChargeSceneView(this) { stopOverlay(); stopSelf() }
        overlay = view
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.OPAQUE
        ).apply { gravity = Gravity.TOP or Gravity.START }
        try { wm.addView(view, params) } catch (_: Exception) { overlay = null }
    }

    private fun stopOverlay() {
        try { overlay?.let { wm.removeView(it) } } catch (_: Exception) {}
        overlay = null
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "CHARGE 3D", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    override fun onDestroy() { stopOverlay(); super.onDestroy() }

    companion object {
        const val ACTION_START = "com.logika.charge3d.START"
        const val ACTION_STOP = "com.logika.charge3d.STOP"
    }
}
