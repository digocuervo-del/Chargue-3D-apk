package com.logika.charge3d

import android.content.*
import android.graphics.*
import android.view.View
import kotlin.math.*
import kotlin.random.Random

class ChargeSceneView(context: Context, private val onClose: () -> Unit) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = RectF()
    private val scene = Random.nextInt(3)
    private var level = 0
    private var finishedAt = 0L
    private var lastTap = 0L
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val raw = i?.getIntExtra("level", 0) ?: 0
            val scale = i?.getIntExtra("scale", 100) ?: 100
            level = if (scale > 0) (raw * 100 / scale).coerceIn(0, 100) else 0
            if (level >= 100 && finishedAt == 0L) finishedAt = System.currentTimeMillis()
            invalidate()
        }
    }

    init {
        isClickable = true
        context.registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        if (event.action == android.view.MotionEvent.ACTION_DOWN) {
            val now = System.currentTimeMillis()
            if (now - lastTap < 500) onClose()
            lastTap = now
            return true
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (finishedAt > 0L && System.currentTimeMillis() - finishedAt > 2800L) {
            canvas.drawColor(Color.BLACK)
            postInvalidateDelayed(1000)
            return
        }
        when (scene) {
            0 -> drawBus(canvas, w, h)
            1 -> drawMeteor(canvas, w, h)
            else -> drawRunner(canvas, w, h)
        }
        drawHud(canvas, w, h)
        postInvalidateDelayed(32)
    }

    private fun bg(c: Canvas, w: Float, h: Float, top: Int, bottom: Int) {
        paint.shader = LinearGradient(0f, 0f, 0f, h, top, bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint); paint.shader = null
    }
    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false) {
        paint.color = color; paint.textSize = size; paint.typeface = if (bold) Typeface.create("sans-serif-black", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL); paint.textAlign = Paint.Align.CENTER
        c.drawText(s, x, y, paint)
    }
    private fun round(c: Canvas, l: Float, t: Float, r: Float, b: Float, radius: Float, color: Int) {
        paint.color = color; paint.shader = null; c.drawRoundRect(l,t,r,b,radius,radius,paint)
    }

    private fun drawBus(c: Canvas, w: Float, h: Float) {
        bg(c,w,h,0xFF101D38.toInt(),0xFF070B14.toInt())
        // city skyline and street
        for (i in 0..8) {
            val x = i*w/8f
            val bh = h*(0.12f + ((i*37)%9)/100f)
            paint.color = 0xFF172943.toInt(); c.drawRect(x,h*0.49f-bh,x+w/10f,h*0.53f,paint)
            for (j in 0..2) { paint.color = 0xFF52627B.toInt(); c.drawRect(x+8+j*13,h*0.49f-bh+12,x+14+j*13,h*0.49f-bh+20,paint) }
        }
        paint.color = 0xFF252C38.toInt(); c.drawRect(0f,h*.53f,w,h,paint)
        paint.color = 0xFF596273.toInt(); paint.strokeWidth=4f; paint.pathEffect=DashPathEffect(floatArrayOf(35f,28f),0f); c.drawLine(0f,h*.83f,w,h*.83f,paint); paint.pathEffect=null
        val progress=level/100f; val bx=w*.10f; val by=h*.55f; val bw=w*.80f; val bh=h*.28f
        // bus body and front
        round(c,bx,by,bx+bw,by+bh,26f,0xFFE5A51B.toInt())
        round(c,bx+12,by+12,bx+bw-20,by+bh*.58f,12f,0xFF152A40.toInt())
        for (i in 0..5) {
            val x=bx+24+i*(bw-62)/6f
            round(c,x,by+22,x+((bw-90)/6f),by+bh*.53f,7f,0xFF8CC8E8.toInt())
            // seated passenger heads and shoulders
            if (i < ceil(progress*6).toInt()) {
                paint.color=when(i%3){0->0xFFF1C6A1.toInt();1->0xFF9D684C.toInt();else->0xFFD9A77F.toInt()}; c.drawCircle(x+((bw-90)/12f),by+bh*.25f,10f,paint)
                paint.color=when(i%2){0->0xFF263B64.toInt();else->0xFF8D3440.toInt()}; c.drawRoundRect(x+((bw-90)/12f)-10,by+bh*.31f,x+((bw-90)/12f)+10,by+bh*.52f,7f,7f,paint)
            }
        }
        round(c,bx+bw-42,by+bh*.60f,bx+bw-10,by+bh*.92f,5f,0xFF27364A.toInt())
        paint.color=0xFF121820.toInt(); c.drawCircle(bx+bw*.22f,by+bh, bh*.16f,paint); c.drawCircle(bx+bw*.78f,by+bh,bh*.16f,paint)
        paint.color=0xFF9BA7B5.toInt(); c.drawCircle(bx+bw*.22f,by+bh,bh*.075f,paint); c.drawCircle(bx+bw*.78f,by+bh,bh*.075f,paint)
        text(c,"SUBIENDO PASAJEROS",w/2,h*.17f,22f,Color.WHITE,true)
        text(c,"${(progress*6).toInt()} / 6 pasajeros",w/2,h*.22f,16f,0xFFFFD27A.toInt())
        if (level>=100) { text(c,"¡PRÓXIMA PARADA!",w/2,h*.38f,20f,0xFFFFD27A.toInt(),true) }
    }

    private fun drawMeteor(c: Canvas, w: Float, h: Float) {
        bg(c,w,h,0xFF020617.toInt(),0xFF24102B.toInt())
        val rnd=Random(9)
        for(i in 0..90){ val x=rnd.nextFloat()*w; val y=rnd.nextFloat()*h*.72f; paint.color=0x99FFFFFF.toInt(); c.drawCircle(x,y,1f+(i%3),paint) }
        // distant horizon glow
        paint.shader=RadialGradient(w*.54f,h*.72f,w*.55f,intArrayOf(0x99FF6B2E.toInt(),0x22C13B27,0x00000000),null,Shader.TileMode.CLAMP); c.drawRect(0f,h*.2f,w,h,paint); paint.shader=null
        val p=level/100f; val size=w*(.10f+.72f*p); val x=w*(.76f-.28f*p); val y=h*(.18f+.55f*p)
        paint.shader=LinearGradient(x-size*.8f,y-size*.8f,x+size*.6f,y+size*.5f,0x00FF6A21,0xAAFF6A21,Shader.TileMode.CLAMP)
        val trail=Path().apply { moveTo(x-size*.15f,y-size*.1f); lineTo(x-size*2.4f,y-size*1.5f); lineTo(x-size*1.5f,y+size*.3f); close() }; c.drawPath(trail,paint); paint.shader=null
        paint.shader=RadialGradient(x-size*.2f,y-size*.2f,size,intArrayOf(0xFFFFE5A1.toInt(),0xFFCE6941.toInt(),0xFF63352F.toInt(),0xFF241B25.toInt()),floatArrayOf(0f,.42f,.78f,1f),Shader.TileMode.CLAMP)
        c.drawCircle(x,y,size*.52f,paint); paint.shader=null
        paint.color=0x88FF9A54.toInt(); c.drawCircle(x-size*.18f,y-size*.12f,size*.11f,paint); c.drawCircle(x+size*.15f,y+size*.14f,size*.08f,paint)
        text(c,"IMPACTO INMINENTE",w/2,h*.13f,22f,Color.WHITE,true)
        if(level>=100){ paint.color=0xAAFFFFFF.toInt(); paint.strokeWidth=5f; for(i in 0..9){ val a=i*PI/5; c.drawLine(x,y,x+cos(a).toFloat()*w*.7f,y+sin(a).toFloat()*w*.7f,paint) }; text(c,"¡IMPACTO!",w/2,h*.84f,28f,Color.WHITE,true) }
    }

    private fun drawRunner(c: Canvas, w: Float, h: Float) {
        bg(c,w,h,0xFF122A48.toInt(),0xFF09111E.toInt())
        // stadium lights and stands
        for(i in 0..5){ val x=i*w/5f; paint.color=0xFF30425B.toInt(); c.drawRect(x,h*.35f,x+w/5f,h*.57f,paint); for(j in 0..5){ paint.color=0xFF6F8198.toInt(); c.drawCircle(x+12+j*18,h*.40f+(j%2)*18,3f,paint) } }
        paint.color=0xFFB8C6D8.toInt(); c.drawRect(0f,h*.57f,w,h*.59f,paint)
        paint.color=0xFFB33C36.toInt(); c.drawRect(0f,h*.59f,w,h,paint)
        for(i in 0..4){ paint.color=0xFFFFD1C9.toInt(); paint.strokeWidth=4f; c.drawLine(i*w/4f,h*.59f,i*w/4f,h,paint) }
        val p=level/100f; val rx=w*(.12f+.70f*p); val ry=h*.70f
        // runner with dynamic limbs
        val swing=sin(System.currentTimeMillis()/110.0).toFloat()*24f
        paint.strokeCap=Paint.Cap.ROUND; paint.strokeWidth=w*.035f; paint.color=0xFF171E2C.toInt()
        c.drawLine(rx,ry+20,rx-25+swing,ry+75,paint); c.drawLine(rx-25+swing,ry+75,rx-45-swing,ry+120,paint)
        c.drawLine(rx,ry+20,rx+25-swing,ry+72,paint); c.drawLine(rx+25-swing,ry+72,rx+60+swing,ry+100,paint)
        paint.strokeWidth=w*.045f; paint.color=0xFF00C7D9.toInt(); c.drawLine(rx,ry-5,rx-8,ry+65,paint)
        paint.strokeWidth=w*.025f; c.drawLine(rx-3,ry+10,rx-38-swing,ry+42,paint); c.drawLine(rx-3,ry+10,rx+35+swing,ry+38,paint)
        paint.color=0xFFE8B58F.toInt(); c.drawCircle(rx,ry-32,17f,paint)
        paint.color=0xFF202B3C.toInt(); c.drawArc(rx-19,ry-51,rx+19,ry-18,180f,180f,false,paint)
        // finish banner
        paint.color=Color.WHITE; paint.strokeWidth=6f; c.drawLine(w*.90f,h*.36f,w*.90f,h*.62f,paint); round(c,w*.90f-50,h*.36f,w*.90f+4,h*.43f,4f,0xFFFFD34D.toInt())
        text(c,"¡A LA META!",w/2,h*.14f,23f,Color.WHITE,true)
        if(level>=100){ val rnd=Random(5); for(i in 0..45){ val x=w*.5f+(rnd.nextFloat()-.5f)*w; val y=h*.25f+rnd.nextFloat()*h*.35f; paint.color=when(i%3){0->0xFFFFD34D.toInt();1->0xFFFF5E78.toInt();else->0xFF63E6FF.toInt()}; c.drawCircle(x,y,2f+(i%4),paint) }; text(c,"¡META Y FUEGOS ARTIFICIALES!",w/2,h*.88f,17f,Color.WHITE,true) }
    }

    private fun drawHud(c: Canvas,w:Float,h:Float){
        // subtle battery progress bar and percentage
        round(c,w*.12f,h*.91f,w*.88f,h*.925f,8f,0x665B6A80)
        round(c,w*.12f,h*.91f,w*(.12f+.76f*level/100f),h*.925f,8f,0xFF19D5E5.toInt())
        text(c,"$level%",w/2,h*.975f,20f,Color.WHITE,true)
    }
}
