package com.logika.charge3d

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF080D18.toInt())
        }
        val title = TextView(this).apply {
            text = "CHARGE 3D"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Animaciones de carga aleatorias\nColectivo • Meteorito • Corredor\n\nPara activarse al conectar el cargador, permití mostrar sobre otras aplicaciones."
            textSize = 16f
            setTextColor(0xFFCAD4E5.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 28)
        }
        val permission = Button(this).apply {
            text = "CONCEDER PERMISO DE PANTALLA"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        val test = Button(this).apply {
            text = "PROBAR ANIMACIÓN"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startForegroundService(Intent(this@MainActivity, ChargeOverlayService::class.java).setAction(ChargeOverlayService.ACTION_START))
                } else Toast.makeText(this@MainActivity, "Primero concedé el permiso de pantalla", Toast.LENGTH_LONG).show()
            }
        }
        val note = TextView(this).apply {
            text = "La animación se elige al azar al conectar el cargador. Tocá dos veces la pantalla para cerrar la vista."
            textSize = 13f
            setTextColor(0xFF8D9BB2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title); root.addView(desc); root.addView(permission); root.addView(test); root.addView(note)
        setContentView(root)
    }
}
