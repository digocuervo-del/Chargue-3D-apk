package com.logika.charge3d

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class PowerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                if (android.provider.Settings.canDrawOverlays(context)) {
                    val service = Intent(context, ChargeOverlayService::class.java).setAction(ChargeOverlayService.ACTION_START)
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service) else context.startService(service)
                    } catch (_: Exception) { /* Some vendor builds may defer background starts; user can launch the test from the app. */ }
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> context.stopService(Intent(context, ChargeOverlayService::class.java))
        }
    }
}
